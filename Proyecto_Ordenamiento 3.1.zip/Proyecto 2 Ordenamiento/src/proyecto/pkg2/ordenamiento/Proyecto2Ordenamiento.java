
package proyecto.pkg2.ordenamiento;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Proyecto2Ordenamiento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = sc.nextInt();
        Arreglo calculos = new Arreglo(n);
        System.out.println("Datos: " + Arrays.toString(calculos.arreglo));
        System.out.println("Media: " + calculos.Media());
        System.out.println("Mediana: " + calculos.Mediana());
        System.out.println("Varianza: " + calculos.Varianza());
        System.out.println("Desviación estándar: " + calculos.desviacionEstandar());
        System.out.println("Moda: " + calculos.Moda());
        
    }
    
}
