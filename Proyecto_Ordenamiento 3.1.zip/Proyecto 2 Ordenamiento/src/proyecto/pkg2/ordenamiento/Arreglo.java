package proyecto.pkg2.ordenamiento;

import java.util.Arrays;
import java.util.Random;

public class Arreglo {
    //Atributos
    public double [] arreglo;
    
    //Metodos
    public Arreglo(int n){
        arreglo = new double[n];  
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            arreglo[i] = rand.nextDouble() * 100; // Genera números aleatorios entre 0 y 100
        }
    }
    public double Media(){
        double suma = 0.0;
        for (double dato : arreglo ) {
            suma += dato;
        }
        return suma / arreglo.length;
    };
    public double Mediana(){
          double[] copiaArreglo = Arrays.copyOf(arreglo, arreglo.length);
        Arrays.sort(copiaArreglo);
        if (copiaArreglo.length % 2 == 0) {
            int mitad = copiaArreglo.length / 2;
            return (copiaArreglo[mitad - 1] + copiaArreglo[mitad]) / 2.0;
        } else {
            int mitad = (copiaArreglo.length - 1) / 2;
            return copiaArreglo[mitad];
        }
    };
    public double Varianza(){
         double media = Media();
        double suma = 0.0;
        for (double dato : arreglo) {
            suma += Math.pow(dato - media, 2);
        }
        return suma / arreglo.length;
    };
    public double desviacionEstandar(){
         return Math.sqrt(Varianza());
    };
    public double Moda(){
        double moda = arreglo[0];
        int repeticiones = 0;
        for (int i = 0; i < arreglo.length; i++) {
            int conteo = 0;
            for (int j = 0; j < arreglo.length; j++) {
                if (arreglo[j] == arreglo[i]) {
                    conteo++;
                }
            }
            if (conteo > repeticiones) {
                repeticiones = conteo;
                moda = arreglo[i];
            }
        }
        return moda;
    };
    
    
}
