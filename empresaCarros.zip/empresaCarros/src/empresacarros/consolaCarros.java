
package empresacarros;


import java.util.Arrays;
import java.util.Scanner;

public class consolaCarros extends claseMenuPrincipal {
       
    public static void main(String[] args) {
        int cantidad;
        String marca,color;
        int modelo;
        int kilometraje;
        int ord;
        
       
        
        claseMenuPrincipal objeto2 = new claseMenuPrincipal();
        Scanner objeto = new Scanner(System.in);
        System.out.println("Digite la cantidad de carros");
        cantidad =objeto.nextInt();
        
        
        int[] arreglomod=new int[cantidad];
        int[] arreglokil=new int[cantidad];
        consolaCarros arrayCar[] = new consolaCarros[cantidad];
        //consolaCarros Car = new consolaCarros();
        for (int i = 0; i < cantidad; i++) {
            //arrayCar[i]=new consolaCarros();
            System.out.println("Carro Numero "+(i+1));
            System.out.println("Digite la marca :");
            marca=objeto.next();
            System.out.println("Digite el modelo");
            modelo=objeto.nextInt();
            System.out.println("Digite el color");
            color=objeto.next();
            System.out.println("Digite el kilometraje");
            kilometraje=objeto.nextInt();
            arrayCar[i].cosncar(i, marca, color, modelo, kilometraje);
            arreglomod[i]=modelo;
            arreglokil[i]=kilometraje;
        }
        System.out.println("como desea ordenar los datos?");
        System.out.println("1.Modelo");
        System.out.println("2.Kilometraje");
        ord=objeto.nextInt();
        switch(ord){
            case 1:
               System.out.println("Consulta por orden de modelo");
                System.out.println(Arrays.toString(objeto2.burbuja(arreglomod)));
                break;
            case 2:
                System.out.println("Consulta por orden de kilometraje");
                System.out.println(Arrays.toString(objeto2.burbuja(arreglokil)));
                break;
        }
    }
    
}


