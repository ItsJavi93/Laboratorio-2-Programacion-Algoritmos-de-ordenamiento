
package empresacarros;

import java.util.ArrayList;
import java.util.Arrays;

public class menuPrincipal extends javax.swing.JFrame {
    int modelo;
    int kilometraje;
    String color;
    String marca;
    public int arr;
    int cont=0;
    
    int[] arreglomod=new int[arr];
    int[] arreglokil=new int[arr];
    ArrayList<claseMenuPrincipal> car= new ArrayList<claseMenuPrincipal>();
    
    public void Arr(int arr){
        this.arr=arr;
        Indice.setText(String.valueOf(arr-1));
    }
    
    
    
    public menuPrincipal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Contador = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Indice = new javax.swing.JLabel();
        Marca = new javax.swing.JLabel();
        Color = new javax.swing.JLabel();
        Modelo = new javax.swing.JLabel();
        Kilometraje = new javax.swing.JLabel();
        Mar = new javax.swing.JTextField();
        Col = new javax.swing.JTextField();
        Mod = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Kilo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Imprimir = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        OrdMod = new javax.swing.JButton();
        OrdKil = new javax.swing.JButton();
        Ingresar = new javax.swing.JButton();
        Atras = new javax.swing.JButton();
        Adelante = new javax.swing.JButton();
        pp = new javax.swing.JComboBox<>();
        Fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Contador.setText("0");
        jPanel1.add(Contador, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 10, -1));

        jLabel3.setText("de");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, -1, -1));

        Indice.setText("0");
        jPanel1.add(Indice, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 20, -1));

        Marca.setText("Marca:");
        jPanel1.add(Marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        Color.setForeground(new java.awt.Color(255, 255, 255));
        Color.setText("Color:");
        jPanel1.add(Color, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        Modelo.setText("Modelo:");
        jPanel1.add(Modelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        Kilometraje.setForeground(new java.awt.Color(255, 255, 255));
        Kilometraje.setText("Kilometraje:");
        jPanel1.add(Kilometraje, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, -1, -1));

        Mar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MarActionPerformed(evt);
            }
        });
        jPanel1.add(Mar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 150, -1));

        Col.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ColActionPerformed(evt);
            }
        });
        jPanel1.add(Col, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 150, -1));
        jPanel1.add(Mod, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 150, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel1.setText("Año");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Km");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, -1, -1));
        jPanel1.add(Kilo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 150, -1));

        Imprimir.setEditable(false);
        Imprimir.setColumns(20);
        Imprimir.setRows(5);
        jScrollPane1.setViewportView(Imprimir);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, 190, -1));

        jPanel3.setBackground(java.awt.SystemColor.inactiveCaption);
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones\n", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N
        jPanel3.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanel3AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Desea ordenar el:");

        OrdMod.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        OrdMod.setText("Modelo");
        OrdMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrdModActionPerformed(evt);
            }
        });

        OrdKil.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        OrdKil.setText("Kilometraje");
        OrdKil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrdKilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(OrdMod)
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(OrdKil)
                .addGap(17, 17, 17))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(12, 12, 12)
                .addComponent(OrdMod)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(OrdKil)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 140, 130));

        Ingresar.setText("Ingresar");
        Ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarActionPerformed(evt);
            }
        });
        jPanel1.add(Ingresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, -1, -1));

        Atras.setText("←");
        Atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtrasActionPerformed(evt);
            }
        });
        jPanel1.add(Atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, -1, -1));

        Adelante.setText("→");
        Adelante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdelanteActionPerformed(evt);
            }
        });
        jPanel1.add(Adelante, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, -1, -1));

        pp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Burbuja", "megersort" }));
        jPanel1.add(pp, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, -1, -1));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenInicio/f7938755f73c7c3358a7a65cd67e679b.jpg"))); // NOI18N
        jPanel1.add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 308, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MarActionPerformed

    private void ColActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ColActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ColActionPerformed

    private void jPanel3AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanel3AncestorAdded
       
    }//GEN-LAST:event_jPanel3AncestorAdded

    private void OrdModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrdModActionPerformed
    int h=pp.getSelectedIndex();
    if(h==0){
        consolaCarros carro = new consolaCarros();
        int num;
        num=Integer.parseInt(Indice.getText());
        int mod[]= new int[num+1];
        for (int i = 0; i < num+1; i++) {
            mod[i]=car.get(i).modelo;
        }
        carro.burbuja(mod);
        for (int i = 0; i < num+1; i++) {
            
            Imprimir.setText(Imprimir.getText()+"\n"+String.valueOf(mod[i]));
            System.out.println("modelo: "+mod[i]);
        }
    }
    if(h==1){
    
    }
    }//GEN-LAST:event_OrdModActionPerformed

    private void OrdKilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrdKilActionPerformed
        
        int h=pp.getSelectedIndex();
        if(h==0){
        consolaCarros carro = new consolaCarros();
        int num;
        num=Integer.parseInt(Indice.getText());
        int mod[]= new int[num+1];
        for (int i = 0; i < num+1; i++) {
            mod[i]=car.get(i).kilometraje;
        }
        carro.burbuja(mod);
        for (int i = 0; i < num+1; i++) {
            Imprimir.setText(Imprimir.getText()+"\n"+String.valueOf(mod[i]));
            System.out.println("Kilometraje: "+mod[i]);
        }
       }
        if(h==1){
    
    }
    }//GEN-LAST:event_OrdKilActionPerformed

    private void IngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarActionPerformed
        
    
        color=Col.getText();
        marca=Mar.getText();
        modelo=Integer.parseInt(Mod.getText());
        kilometraje=Integer.parseInt(Kilo.getText());
        consolaCarros carro = new consolaCarros();
        carro.cosncar(cont, marca, color, modelo, kilometraje);
        car.add(carro);
        cont=Integer.parseInt(Contador.getText());
        Col.setText("");
        Mar.setText("");
        Mod.setText("");
        Kilo.setText("");
        cont++;
        //Evaluar si ya se completo la cantidad en la lista
        if(cont>Integer.parseInt(Indice.getText())){
           Ingresar.setVisible(false);
           Contador.setText(String.valueOf(cont-1));
           Atras.setVisible(true);
           Adelante.setVisible(true);
           OrdKil.setVisible(true);
           OrdMod.setVisible(true);
           
        }
        //cambiar contador y continuar tomando datos
        else{
        Contador.setText(String.valueOf(cont));
        }
        
    }//GEN-LAST:event_IngresarActionPerformed

    private void AdelanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdelanteActionPerformed
        cont=Integer.parseInt(Contador.getText());
        cont++;
        if(cont>Integer.parseInt(Indice.getText())){
            cont--;
        }   
        else{
            Col.setText(car.get(cont).color);
            Mar.setText(car.get(cont).marca);
            Mod.setText(String.valueOf(car.get(cont).modelo));
            Kilo.setText(String.valueOf(car.get(cont).kilometraje));
            Contador.setText(String.valueOf(cont));
        }
    }//GEN-LAST:event_AdelanteActionPerformed

    private void AtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtrasActionPerformed
       cont=Integer.parseInt(Contador.getText());
        cont--;
        if(cont<0){
            cont++;
        }   
        else{
            Col.setText(car.get(cont).color);
            Mar.setText(car.get(cont).marca);
            Mod.setText(String.valueOf(car.get(cont).modelo));
            Kilo.setText(String.valueOf(car.get(cont).kilometraje));
            Contador.setText(String.valueOf(cont));
        }
    }//GEN-LAST:event_AtrasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Adelante;
    private javax.swing.JButton Atras;
    private javax.swing.JTextField Col;
    private javax.swing.JLabel Color;
    private javax.swing.JLabel Contador;
    private javax.swing.JLabel Fondo;
    private javax.swing.JTextArea Imprimir;
    private javax.swing.JLabel Indice;
    private javax.swing.JButton Ingresar;
    private javax.swing.JTextField Kilo;
    private javax.swing.JLabel Kilometraje;
    private javax.swing.JTextField Mar;
    private javax.swing.JLabel Marca;
    private javax.swing.JTextField Mod;
    private javax.swing.JLabel Modelo;
    private javax.swing.JButton OrdKil;
    private javax.swing.JButton OrdMod;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> pp;
    // End of variables declaration//GEN-END:variables
}
