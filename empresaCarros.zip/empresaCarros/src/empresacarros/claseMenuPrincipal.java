
package empresacarros;

public class claseMenuPrincipal {
   //Atributos Menu Principal
    public String marca;
    public int modelo;
    public String color;
    public int kilometraje; 
    
    public void cosncar(int pos,String mar,String col,int mod,int kil){
        marca=mar;
        color=col;
        modelo=mod;
        kilometraje=kil;
    }
   
    
    // Algoritmo de ordenamiento Burbuja
    public int[] burbuja(int[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            for (int j = 0; j < arreglo.length - 1; j++) {
                if (arreglo[j] > arreglo[j+1]) {
                    int temp = arreglo[j];
                    arreglo[j] = arreglo[j+1];
                    arreglo[j+1] = temp;
                }
            }
        }
        return arreglo;
    }
    //Metodo de mostrar
    public void mostrar(int[] arreglo){
        System.out.println("El modelo es" + arreglo);
        
    }
    //Algoritmo de ordenamiento Merge Sort
    public void mergesort(double[] arreglo, int num1, int num2){
         
        int mitad;
        
        if (num1<num2){
            mitad=(num1+num2)/2;
            mergesort (arreglo, num1, num2);
            mergesort (arreglo, mitad+1, num2);
            mezcla (arreglo, num1, mitad, num2);
        }
    }
    public void mezcla (double [] arreglo, int izquierda, int mitad, int derecha){
       
        double aux []= new double [arreglo.length];
        int x, y, z;
        
        x=z=izquierda;
        
        y=mitad+1;
        
        while (x<=mitad && y<=derecha){
            
            if (arreglo[x]<=arreglo[y]){
                aux[z++]=arreglo[x++];
            }
            else {
                aux[z++]=arreglo[y++];
            }
        }
        
        while (x<=mitad){
            
            aux[z++]=arreglo[x++];
        }
        
        while (y<=derecha){
            
            aux[z++]=arreglo[y++];
        }
    }
}
