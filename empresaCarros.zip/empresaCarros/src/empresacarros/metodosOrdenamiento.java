
package empresacarros;

public class metodosOrdenamiento {

    //atributos 
    public int tamaño;
    public double[] arreglo;
   
    

// Método para generar un arreglo de números aleatorios
    public double[] generarArreglo(int a) {
        double[] numeros = new double[a];
        for (int i = 0; i < a; i++) {
            numeros[i] = Math.random() * 100;
        }
        return numeros;
    }
// Algoritmo de ordenamiento Burbuja
    public double[] burbuja(double[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            for (int j = 0; j < arreglo.length - 1; j++) {
                if (arreglo[j] > arreglo[j+1]) {
                    double temp = arreglo[j];
                    arreglo[j] = arreglo[j+1];
                    arreglo[j+1] = temp;
                }
            }
        }
        return arreglo;
    }
    
// Algoritmo de ordenamiento Inserción
    public double[] insercion(double[] arreglo) {
        for (int i = 1; i < arreglo.length; i++) {
            double valorActual = arreglo[i];
            int j = i - 1;
            while (j >= 0 && arreglo[j] > valorActual) {
                arreglo[j+1] = arreglo[j];
                j--;
            }
            arreglo[j+1] = valorActual;
        }
        return arreglo;
    }
    
// Algoritmo de ordenamiento Selección
    public double[] seleccion(double[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            int indiceMenor = i;
            for (int j = i + 1; j < arreglo.length; j++) {
                if (arreglo[j] < arreglo[indiceMenor]) {
                    indiceMenor = j;
                }
            }
            double temp = arreglo[i];
            arreglo[i] = arreglo[indiceMenor];
            arreglo[indiceMenor] = temp;
        }
        return arreglo;
    }
    //Algoritmo de ordenamiento Merge Sort
    public void mergesort(double[] arreglo, int num1, int num2){
         
        int mitad;
        
        if (num1<num2){
            mitad=(num1+num2)/2;
            mergesort (arreglo, num1, num2);
            mergesort (arreglo, mitad+1, num2);
            mezcla (arreglo, num1, mitad, num2);
        }
    }
    public void mezcla (double [] arreglo, int izquierda, int mitad, int derecha){
       
        double aux []= new double [arreglo.length];
        int x, y, z;
        
        x=z=izquierda;
        
        y=mitad+1;
        
        while (x<=mitad && y<=derecha){
            
            if (arreglo[x]<=arreglo[y]){
                aux[z++]=arreglo[x++];
            }
            else {
                aux[z++]=arreglo[y++];
            }
        }
        
        while (x<=mitad){
            
            aux[z++]=arreglo[x++];
        }
        
        while (y<=derecha){
            
            aux[z++]=arreglo[y++];
        }
    }
    
}


    