
package programa3.pkg2;

import java.util.Scanner;
public class NewMain {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //utiliza la clase Scanner para leer la línea de caracteres desde la consola
        int op;
        System.out.print("Introduce una linea: ");
        String linea = scanner.nextLine();
        Operaciones operaciones = new Operaciones(linea);
        do{
        System.out.println("====== MENU ======");
        System.out.println("1. Mostrar linea de caracteres");
        System.out.println("2. Linea Sustituida");
        System.out.println("3. Linea Invertida");
        System.out.println("4. Salir");
        System.out.println("Ingrese una opcion: ");
        op=scanner.nextInt();
        
        switch(op)
        {
            case 1:
        System.out.println("caracteres: " + linea);
        break;
            case 2:
        System.out.println("linea con vocales Sustituidas: " + operaciones.Sustituida );
        break;
            case 3:
        System.out.println("linea invertida: " + operaciones.Invertida );
        break;
        }

        }while(op>=1&&op<=4);
 
        
        operaciones.Resultados();
    }
    }
    

