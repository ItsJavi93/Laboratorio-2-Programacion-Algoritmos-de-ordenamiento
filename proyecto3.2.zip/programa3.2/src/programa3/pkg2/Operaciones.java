package programa3.pkg2;
import java.util.*;

public class Operaciones {
    
    private final String linea;
    private final Map<Character, Integer> frecuencia;
    private char MasComun;
    public String Sustituida;
    public String Invertida;
   
    
    public Operaciones(String linea) {
        this.linea = linea;
        this.frecuencia = new HashMap<>();
        contarFrecuencia();
        CaracterComun();
        sustituirV();
        invertir();
       
    }
    
    private void contarFrecuencia() {
        for (char cf : linea.toCharArray()) {
            if (frecuencia.containsKey(cf)) {
                frecuencia.put(cf, frecuencia.get(cf) + 1);
            } else {
                frecuencia.put(cf, 1);
            }
        }
    }
    
    private void CaracterComun() {
        this.MasComun = Collections.max(frecuencia.entrySet(), Map.Entry.comparingByValue()).getKey();//almacena la clave y el valor juntos en una clase, los obtenemos en una sola operación
    }
    
    private void sustituirV() {
        this.Sustituida = linea.replaceAll("[a,e,i,o,u,A,E,I,O,U]", Character.toString(MasComun));
    }
    
    private void invertir() {
        this.Invertida = new StringBuilder(Sustituida).reverse().toString();
    }
    
    public void Resultados() {
        System.out.println("Linea ingresada: " + linea);
        System.out.println("Linea sustituida: " + Sustituida);
        System.out.println("Linea invertida: " + Invertida);
    }
}
